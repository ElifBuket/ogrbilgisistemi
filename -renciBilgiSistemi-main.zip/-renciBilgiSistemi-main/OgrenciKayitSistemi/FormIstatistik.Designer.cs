﻿namespace OgrenciKayitSistemi
{
    partial class FormIstatistik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblToplam = new Label();
            pbErkek = new ProgressBar();
            pbKadin = new ProgressBar();
            lblErkek = new Label();
            lblKadin = new Label();
            lstDogumYili = new ListBox();
            grpCinsiyet = new GroupBox();
            grpDogumYili = new GroupBox();
            grpCinsiyet.SuspendLayout();
            grpDogumYili.SuspendLayout();
            SuspendLayout();
            // 
            // lblToplam
            // 
            lblToplam.AutoSize = true;
            lblToplam.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lblToplam.Location = new Point(12, 29);
            lblToplam.Name = "lblToplam";
            lblToplam.Size = new Size(185, 25);
            lblToplam.TabIndex = 0;
            lblToplam.Text = "Toplam Öğrenci:0";
            // 
            // pbErkek
            // 
            pbErkek.Location = new Point(171, 29);
            pbErkek.Name = "pbErkek";
            pbErkek.Size = new Size(200, 43);
            pbErkek.TabIndex = 1;
            pbErkek.Click += pbErkek_Click;
            // 
            // pbKadin
            // 
            pbKadin.Location = new Point(171, 78);
            pbKadin.Name = "pbKadin";
            pbKadin.Size = new Size(200, 43);
            pbKadin.TabIndex = 2;
            pbKadin.Click += pbKadin_Click;
            // 
            // lblErkek
            // 
            lblErkek.AutoSize = true;
            lblErkek.Location = new Point(33, 36);
            lblErkek.Name = "lblErkek";
            lblErkek.Size = new Size(71, 20);
            lblErkek.TabIndex = 3;
            lblErkek.Text = "Erkek: 0%";
            // 
            // lblKadin
            // 
            lblKadin.AutoSize = true;
            lblKadin.Location = new Point(33, 88);
            lblKadin.Name = "lblKadin";
            lblKadin.Size = new Size(74, 20);
            lblKadin.TabIndex = 4;
            lblKadin.Text = "Kadın: 0%";
            // 
            // lstDogumYili
            // 
            lstDogumYili.FormattingEnabled = true;
            lstDogumYili.Location = new Point(33, 26);
            lstDogumYili.Name = "lstDogumYili";
            lstDogumYili.Size = new Size(363, 104);
            lstDogumYili.TabIndex = 5;
            lstDogumYili.SelectedIndexChanged += lstDogumYili_SelectedIndexChanged;
            // 
            // grpCinsiyet
            // 
            grpCinsiyet.BackColor = Color.DarkGray;
            grpCinsiyet.Controls.Add(pbErkek);
            grpCinsiyet.Controls.Add(pbKadin);
            grpCinsiyet.Controls.Add(lblKadin);
            grpCinsiyet.Controls.Add(lblErkek);
            grpCinsiyet.Location = new Point(12, 79);
            grpCinsiyet.Name = "grpCinsiyet";
            grpCinsiyet.Size = new Size(424, 133);
            grpCinsiyet.TabIndex = 6;
            grpCinsiyet.TabStop = false;
            grpCinsiyet.Text = "Cinsiyet Dağılımı";
            // 
            // grpDogumYili
            // 
            grpDogumYili.BackColor = Color.DarkGray;
            grpDogumYili.Controls.Add(lstDogumYili);
            grpDogumYili.Location = new Point(12, 235);
            grpDogumYili.Name = "grpDogumYili";
            grpDogumYili.Size = new Size(424, 154);
            grpDogumYili.TabIndex = 7;
            grpDogumYili.TabStop = false;
            grpDogumYili.Text = "Doğum Yılı Dağılımı";
            // 
            // FormIstatistik
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(800, 450);
            Controls.Add(grpDogumYili);
            Controls.Add(grpCinsiyet);
            Controls.Add(lblToplam);
            Name = "FormIstatistik";
            Text = "FormIstatistik";
            grpCinsiyet.ResumeLayout(false);
            grpCinsiyet.PerformLayout();
            grpDogumYili.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblToplam;
        private ProgressBar pbErkek;
        private ProgressBar pbKadin;
        private Label lblErkek;
        private Label lblKadin;
        private ListBox lstDogumYili;
        private GroupBox grpCinsiyet;
        private GroupBox grpDogumYili;
    }
}