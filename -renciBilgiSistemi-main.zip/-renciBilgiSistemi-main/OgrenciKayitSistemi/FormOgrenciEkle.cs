﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    public partial class FormOgrenciEkle : Form
    {
        public FormOgrenciEkle()
        {
            InitializeComponent();
            this.Load += FormOgrenciEkle_Load;
        }

        private void FormOgrenciEkle_Load(object sender, EventArgs e)
        {
            // Bölümleri ekle
            cmbBolum.Items.Clear();
            cmbBolum.Items.Add("Bilgisayar Mühendisliği");
            cmbBolum.Items.Add("Elektrik-Elektronik Mühendisliği");
            cmbBolum.Items.Add("Makine Mühendisliği");

            // Dersleri ekle
            clbDersler.Items.Clear();
            clbDersler.Items.Add("Matematik");
            clbDersler.Items.Add("Fizik");
            clbDersler.Items.Add("Algoritma");

            // Cinsiyet varsayılan
            rbErkek.Checked = true;
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            // Boş alan kontrolleri
            if (string.IsNullOrWhiteSpace(txtAd.Text) ||
                string.IsNullOrWhiteSpace(txtSoyad.Text) ||
                string.IsNullOrWhiteSpace(txtTC.Text) ||
                cmbBolum.SelectedItem == null)
            {
                MessageBox.Show("Lütfen tüm zorunlu alanları doldurun!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (txtTC.Text.Length != 11)
            {
                MessageBox.Show("TC Kimlik Numarası 11 haneli olmalıdır!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Bilgileri alıyoruz
            string ad = txtAd.Text;
            string soyad = txtSoyad.Text;
            string tc = txtTC.Text;
            DateTime dogumTarihi = dtpDogumTarihi.Value;
            string cinsiyet = rbErkek.Checked ? "Erkek" : rbKadin.Checked ? "Kadın" : "Belirtilmedi";
            string bolum = cmbBolum.SelectedItem.ToString();

            // Seçili dersleri listele
            List<string> seciliDersler = new List<string>();
            foreach (var item in clbDersler.CheckedItems)
            {
                seciliDersler.Add(item.ToString());
            }

            string dersler = seciliDersler.Count > 0 ? string.Join(", ", seciliDersler) : "Ders seçilmedi";

            // Yeni öğrenci nesnesi oluştur
            Ogrenci yeniOgrenci = new Ogrenci()
            {
                Ad = ad,
                Soyad = soyad,
                TC = tc,
                DogumTarihi = dogumTarihi,
                Cinsiyet = cinsiyet,
                Bolum = bolum,
                Dersler = dersler
            };

            // Listeye ekle (Ana formdaki listeye)
            Form1.ogrenciListesi.Add(yeniOgrenci);

            MessageBox.Show("Öğrenci başarıyla kaydedildi!");

            // Öğrenci bilgilerini göster
            string mesaj = $"Ad: {ad}\nSoyad: {soyad}\nTC: {tc}\nDoğum Tarihi: {dogumTarihi.ToShortDateString()}\n" +
                           $"Cinsiyet: {cinsiyet}\nBölüm: {bolum}\nDersler: {dersler}";

            MessageBox.Show(mesaj, "Öğrenci Bilgileri", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Formu temizle
            Temizle();
        }

        private void Temizle()
        {
            txtAd.Clear();
            txtSoyad.Clear();
            txtTC.Clear();
            dtpDogumTarihi.Value = DateTime.Now;
            rbErkek.Checked = true;
            rbKadin.Checked = false;
            cmbBolum.SelectedIndex = -1;

            for (int i = 0; i < clbDersler.Items.Count; i++)
            {
                clbDersler.SetItemChecked(i, false);
            }
        }

        // Gereksiz event handlerlar (İstersen silebilirsin)
        private void label1_Click(object sender, EventArgs e) { }

        private void cmbBolum_SelectedIndexChanged(object sender, EventArgs e) { }

        private void clbDersler_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}
