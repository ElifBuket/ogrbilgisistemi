namespace OgrenciKayitSistemi
{
    public partial class Form1 : Form
    {
        public static List<Ogrenci> ogrenciListesi = new List<Ogrenci>();
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void ��renciEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOgrenciEkle frm = new FormOgrenciEkle();
            frm.Show();
        }

        private void ��renciListeleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOgrenciListele frm = new FormOgrenciListele();
            frm.Show();
        }

        private void istatistiklerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormIstatistik frm = new FormIstatistik(ogrenciListesi); // listeyi g�nderiyorsun
            frm.Show();
        }

    }
}
