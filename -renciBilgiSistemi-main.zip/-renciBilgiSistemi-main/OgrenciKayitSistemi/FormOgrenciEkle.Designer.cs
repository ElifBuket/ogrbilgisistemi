﻿namespace OgrenciKayitSistemi
{
    partial class FormOgrenciEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblAd = new Label();
            lblSoyad = new Label();
            lblTC = new Label();
            lblCinsiyet = new Label();
            lblBolum = new Label();
            lblDogumTarihi = new Label();
            lblDersler = new Label();
            txtAd = new TextBox();
            txtSoyad = new TextBox();
            txtTC = new TextBox();
            dtpDogumTarihi = new DateTimePicker();
            rbErkek = new RadioButton();
            rbKadin = new RadioButton();
            cmbBolum = new ComboBox();
            clbDersler = new CheckedListBox();
            grpCinsiyet = new GroupBox();
            btnKaydet = new Button();
            grpCinsiyet.SuspendLayout();
            SuspendLayout();
            // 
            // lblAd
            // 
            lblAd.AutoSize = true;
            lblAd.Location = new Point(12, 9);
            lblAd.Name = "lblAd";
            lblAd.Size = new Size(28, 20);
            lblAd.TabIndex = 0;
            lblAd.Text = "Ad";
            lblAd.Click += label1_Click;
            // 
            // lblSoyad
            // 
            lblSoyad.AutoSize = true;
            lblSoyad.Location = new Point(12, 43);
            lblSoyad.Name = "lblSoyad";
            lblSoyad.Size = new Size(50, 20);
            lblSoyad.TabIndex = 1;
            lblSoyad.Text = "Soyad";
            // 
            // lblTC
            // 
            lblTC.AutoSize = true;
            lblTC.Location = new Point(12, 85);
            lblTC.Name = "lblTC";
            lblTC.Size = new Size(94, 20);
            lblTC.TabIndex = 2;
            lblTC.Text = "TC Kimlik No";
            // 
            // lblCinsiyet
            // 
            lblCinsiyet.AutoSize = true;
            lblCinsiyet.Location = new Point(27, 183);
            lblCinsiyet.Name = "lblCinsiyet";
            lblCinsiyet.Size = new Size(60, 20);
            lblCinsiyet.TabIndex = 3;
            lblCinsiyet.Text = "Cinsiyet";
            // 
            // lblBolum
            // 
            lblBolum.AutoSize = true;
            lblBolum.Location = new Point(16, 231);
            lblBolum.Name = "lblBolum";
            lblBolum.Size = new Size(52, 20);
            lblBolum.TabIndex = 4;
            lblBolum.Text = "Bölüm";
            // 
            // lblDogumTarihi
            // 
            lblDogumTarihi.AutoSize = true;
            lblDogumTarihi.Location = new Point(8, 128);
            lblDogumTarihi.Name = "lblDogumTarihi";
            lblDogumTarihi.Size = new Size(98, 20);
            lblDogumTarihi.TabIndex = 5;
            lblDogumTarihi.Text = "Doğum Tarihi";
            // 
            // lblDersler
            // 
            lblDersler.AutoSize = true;
            lblDersler.Location = new Point(12, 277);
            lblDersler.Name = "lblDersler";
            lblDersler.Size = new Size(56, 20);
            lblDersler.TabIndex = 6;
            lblDersler.Text = "Dersler";
            // 
            // txtAd
            // 
            txtAd.Location = new Point(65, 6);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(137, 27);
            txtAd.TabIndex = 7;
            // 
            // txtSoyad
            // 
            txtSoyad.Location = new Point(77, 43);
            txtSoyad.Name = "txtSoyad";
            txtSoyad.Size = new Size(180, 27);
            txtSoyad.TabIndex = 8;
            // 
            // txtTC
            // 
            txtTC.Location = new Point(118, 85);
            txtTC.MaxLength = 11;
            txtTC.Name = "txtTC";
            txtTC.Size = new Size(185, 27);
            txtTC.TabIndex = 9;
            txtTC.TextChanged += label1_Click;
            // 
            // dtpDogumTarihi
            // 
            dtpDogumTarihi.Format = DateTimePickerFormat.Short;
            dtpDogumTarihi.Location = new Point(128, 128);
            dtpDogumTarihi.Name = "dtpDogumTarihi";
            dtpDogumTarihi.Size = new Size(213, 27);
            dtpDogumTarihi.TabIndex = 10;
            // 
            // rbErkek
            // 
            rbErkek.AutoSize = true;
            rbErkek.Location = new Point(38, 22);
            rbErkek.Name = "rbErkek";
            rbErkek.Size = new Size(65, 24);
            rbErkek.TabIndex = 11;
            rbErkek.TabStop = true;
            rbErkek.Text = "Erkek";
            rbErkek.UseVisualStyleBackColor = true;
            // 
            // rbKadin
            // 
            rbKadin.AutoSize = true;
            rbKadin.Location = new Point(132, 22);
            rbKadin.Name = "rbKadin";
            rbKadin.Size = new Size(68, 24);
            rbKadin.TabIndex = 12;
            rbKadin.TabStop = true;
            rbKadin.Text = "Kadın";
            rbKadin.UseVisualStyleBackColor = true;
            // 
            // cmbBolum
            // 
            cmbBolum.FormattingEnabled = true;
            cmbBolum.Location = new Point(118, 228);
            cmbBolum.Name = "cmbBolum";
            cmbBolum.Size = new Size(212, 28);
            cmbBolum.TabIndex = 13;
            cmbBolum.SelectedIndexChanged += cmbBolum_SelectedIndexChanged;
            // 
            // clbDersler
            // 
            clbDersler.FormattingEnabled = true;
            clbDersler.Location = new Point(118, 277);
            clbDersler.Name = "clbDersler";
            clbDersler.Size = new Size(212, 114);
            clbDersler.TabIndex = 14;
            clbDersler.SelectedIndexChanged += clbDersler_SelectedIndexChanged;
            // 
            // grpCinsiyet
            // 
            grpCinsiyet.Controls.Add(rbErkek);
            grpCinsiyet.Controls.Add(rbKadin);
            grpCinsiyet.Location = new Point(118, 161);
            grpCinsiyet.Name = "grpCinsiyet";
            grpCinsiyet.Size = new Size(240, 49);
            grpCinsiyet.TabIndex = 15;
            grpCinsiyet.TabStop = false;
            // 
            // btnKaydet
            // 
            btnKaydet.Location = new Point(65, 409);
            btnKaydet.Name = "btnKaydet";
            btnKaydet.Size = new Size(94, 29);
            btnKaydet.TabIndex = 16;
            btnKaydet.Text = "Kaydet";
            btnKaydet.UseVisualStyleBackColor = true;
            btnKaydet.Click += btnKaydet_Click;
            // 
            // FormOgrenciEkle
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnKaydet);
            Controls.Add(grpCinsiyet);
            Controls.Add(clbDersler);
            Controls.Add(cmbBolum);
            Controls.Add(dtpDogumTarihi);
            Controls.Add(txtTC);
            Controls.Add(txtSoyad);
            Controls.Add(txtAd);
            Controls.Add(lblDersler);
            Controls.Add(lblDogumTarihi);
            Controls.Add(lblBolum);
            Controls.Add(lblCinsiyet);
            Controls.Add(lblTC);
            Controls.Add(lblSoyad);
            Controls.Add(lblAd);
            Name = "FormOgrenciEkle";
            Text = "FormOgrenciEkle";
            Load += FormOgrenciEkle_Load;
            grpCinsiyet.ResumeLayout(false);
            grpCinsiyet.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAd;
        private Label lblSoyad;
        private Label lblTC;
        private Label lblCinsiyet;
        private Label lblBolum;
        private Label lblDogumTarihi;
        private Label lblDersler;
        private TextBox txtAd;
        private TextBox txtSoyad;
        private TextBox tctTC;
        private DateTimePicker dtpDogumTarihi;
        private RadioButton rbErkek;
        private RadioButton rbKadin;
        private ComboBox cmbBolum;
        private CheckedListBox clbDersler;
        private GroupBox grpCinsiyet;
        private Button btnKaydet;
        private TextBox txtTC;
    }
}