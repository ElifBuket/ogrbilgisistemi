﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    public partial class FormOgrenciListele : Form
    {
        private Button btnIstatistik;

        public FormOgrenciListele()
        {
            InitializeComponent();

            this.Load += FormOgrenciListele_Load;

            txtAra.TextChanged += txtAra_TextChanged;
            btnSil.Click += btnSil_Click;
            btnGuncelle.Click += btnGuncelle_Click;

            btnIstatistik = new Button
            {
                Text = "İstatistikleri Gör",
                Width = 150,
                Height = 30,
                Top = btnGuncelle.Bottom + 10,
                Left = btnGuncelle.Left
            };

            btnIstatistik.Click += btnIstatistik_Click;
            this.Controls.Add(btnIstatistik);

            dgvOgrenciler.CellDoubleClick += dgvOgrenciler_CellDoubleClick;
        }

        private void FormOgrenciListele_Load(object sender, EventArgs e)
        {
            OgrenciListesiniGoster();
        }

        private void OgrenciListesiniGoster()
        {
            dgvOgrenciler.DataSource = null;
            dgvOgrenciler.DataSource = Form1.ogrenciListesi;

            dgvOgrenciler.Columns["Ad"].HeaderText = "Ad";
            dgvOgrenciler.Columns["Soyad"].HeaderText = "Soyad";
            dgvOgrenciler.Columns["Cinsiyet"].HeaderText = "Cinsiyet";
            dgvOgrenciler.Columns["DogumTarihi"].HeaderText = "Doğum Tarihi";
            dgvOgrenciler.Columns["TC"].HeaderText = "TC Kimlik No";
            dgvOgrenciler.Columns["Bolum"].HeaderText = "Bölüm";
            dgvOgrenciler.Columns["DerslerGosterim"].HeaderText = "Dersler";


        }

        private void txtAra_TextChanged(object sender, EventArgs e)
        {
            string aranan = txtAra.Text.Trim().ToLower();

            var filtreliListe = Form1.ogrenciListesi
                .Where(o => o.Ad.ToLower().Contains(aranan) || o.Soyad.ToLower().Contains(aranan))
                .ToList();

            dgvOgrenciler.DataSource = null;
            dgvOgrenciler.DataSource = filtreliListe;
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dgvOgrenciler.CurrentRow != null)
            {
                var seciliOgrenci = dgvOgrenciler.CurrentRow.DataBoundItem as Ogrenci;

                DialogResult sonuc = MessageBox.Show(
                    $"{seciliOgrenci.Ad} {seciliOgrenci.Soyad} öğrencisini silmek istiyor musunuz?",
                    "Öğrenci Sil",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (sonuc == DialogResult.Yes)
                {
                    Form1.ogrenciListesi.Remove(seciliOgrenci);

                    MessageBox.Show("Öğrenci başarıyla silindi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Listeyi yeniden göster + filtreyi uygula
                    txtAra_TextChanged(null, null);
                }
            }
            else
            {
                MessageBox.Show("Lütfen silmek için bir öğrenci seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvOgrenciler.CurrentRow != null)
            {
                var seciliOgrenci = dgvOgrenciler.CurrentRow.DataBoundItem as Ogrenci;

                string yeniAd = Microsoft.VisualBasic.Interaction.InputBox(
                    "Yeni adı giriniz:", "Ad Düzenle", seciliOgrenci.Ad);

                string yeniSoyad = Microsoft.VisualBasic.Interaction.InputBox(
                    "Yeni soyadı giriniz:", "Soyad Düzenle", seciliOgrenci.Soyad);

                if (!string.IsNullOrWhiteSpace(yeniAd))
                    seciliOgrenci.Ad = yeniAd;

                if (!string.IsNullOrWhiteSpace(yeniSoyad))
                    seciliOgrenci.Soyad = yeniSoyad;

                MessageBox.Show("Öğrenci bilgileri güncellendi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                txtAra_TextChanged(null, null); // Filtreli listeyse onu koru
            }
            else
            {
                MessageBox.Show("Güncellemek için bir öğrenci seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnIstatistik_Click(object sender, EventArgs e)
        {
            if (Form1.ogrenciListesi == null || Form1.ogrenciListesi.Count == 0)
            {
                MessageBox.Show("Öğrenci listesi boş! İstatistik görüntülenemiyor.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            FormIstatistik frmIstatistik = new FormIstatistik(Form1.ogrenciListesi);
            frmIstatistik.ShowDialog();
        }

        private void dgvOgrenciler_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            btnGuncelle_Click(sender, e);
        }
    }
}
