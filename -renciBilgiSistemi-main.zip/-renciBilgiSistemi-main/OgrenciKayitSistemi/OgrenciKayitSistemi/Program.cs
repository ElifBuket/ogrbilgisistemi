using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    internal static class Program
    {
        // Kullan�c� listesi burada tutuluyor
        public static List<Kullanici> kullaniciListesi = new List<Kullanici>
        {
            // Admin kullan�c� bilgileri
            new Kullanici("elifbuket", "1234", "Admin"),

            // Normal kullan�c� bilgileri
            new Kullanici("�i�ek", "4321", "Kullanici"),
            new Kullanici("zehra", "0000", "Kullanici")
        };

        /// <summary>
        /// Uygulaman�n ana giri� noktas�
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // �lk a��lacak form: Giri� Formu
            Application.Run(new FormGiris());
        }
    }
}
