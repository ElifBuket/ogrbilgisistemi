﻿namespace OgrenciKayitSistemi
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            öğrenciEkleToolStripMenuItem = new ToolStripMenuItem();
            öğrenciListeleToolStripMenuItem = new ToolStripMenuItem();
            istatistiklerToolStripMenuItem = new ToolStripMenuItem();
            cikisToolStripMenuItem = new ToolStripMenuItem();
            lblKullaniciBilgi = new ToolStripLabel();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { öğrenciEkleToolStripMenuItem, öğrenciListeleToolStripMenuItem, istatistiklerToolStripMenuItem, cikisToolStripMenuItem, lblKullaniciBilgi });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // öğrenciEkleToolStripMenuItem
            // 
            öğrenciEkleToolStripMenuItem.Name = "öğrenciEkleToolStripMenuItem";
            öğrenciEkleToolStripMenuItem.Size = new Size(106, 24);
            öğrenciEkleToolStripMenuItem.Text = "Öğrenci Ekle";
            öğrenciEkleToolStripMenuItem.Click += öğrenciEkleToolStripMenuItem_Click;
            // 
            // öğrenciListeleToolStripMenuItem
            // 
            öğrenciListeleToolStripMenuItem.Name = "öğrenciListeleToolStripMenuItem";
            öğrenciListeleToolStripMenuItem.Size = new Size(121, 24);
            öğrenciListeleToolStripMenuItem.Text = "Öğrenci Listele";
            öğrenciListeleToolStripMenuItem.Click += öğrenciListeleToolStripMenuItem_Click;
            // 
            // istatistiklerToolStripMenuItem
            // 
            istatistiklerToolStripMenuItem.Name = "istatistiklerToolStripMenuItem";
            istatistiklerToolStripMenuItem.Size = new Size(94, 24);
            istatistiklerToolStripMenuItem.Text = "İstatistikler";
            istatistiklerToolStripMenuItem.Click += istatistiklerToolStripMenuItem_Click;
            // 
            // cikisToolStripMenuItem
            // 
            cikisToolStripMenuItem.Name = "cikisToolStripMenuItem";
            cikisToolStripMenuItem.Size = new Size(53, 24);
            cikisToolStripMenuItem.Text = "Çıkış";
            cikisToolStripMenuItem.Click += cikisToolStripMenuItem_Click;
            // 
            // lblKullaniciBilgi
            // 
            lblKullaniciBilgi.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblKullaniciBilgi.ForeColor = Color.Blue;
            lblKullaniciBilgi.Name = "lblKullaniciBilgi";
            lblKullaniciBilgi.Size = new Size(222, 21);
            lblKullaniciBilgi.Text = "Hoş geldin, elifbukett (Admin)";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Öğrenci Kayıt Sistemi";
            Load += Form1_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem öğrenciEkleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öğrenciListeleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem istatistiklerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cikisToolStripMenuItem;
        private System.Windows.Forms.ToolStripLabel lblKullaniciBilgi;
    }
}
