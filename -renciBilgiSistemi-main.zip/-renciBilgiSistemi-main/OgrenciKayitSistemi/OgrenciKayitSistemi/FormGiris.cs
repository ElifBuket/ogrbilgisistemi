﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    public partial class FormGiris : Form
    {
        public FormGiris()
        {
            InitializeComponent();

            // Giriş butonuna Enter basıldığında da tıklansın
            this.AcceptButton = btnGiris;

            // Şifre kutusu gizli karakterlerle gösterilsin
            txtSifre.UseSystemPasswordChar = true;

            // FormClosing eventini bağlayabilirsin (tasarım ekranından da bağlanabilir)
            this.FormClosing += FormGiris_FormClosing;
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            string kullaniciAdi = txtKullaniciAdi.Text.Trim().ToLower(); // küçük harfe çevirerek karşılaştırma
            string sifre = txtSifre.Text;

            if (string.IsNullOrEmpty(kullaniciAdi) || string.IsNullOrEmpty(sifre))
            {
                MessageBox.Show("Lütfen kullanıcı adı ve şifreyi doldurunuz!", "Eksik Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kullanıcıyı listeden bul
            var kullanici = Program.kullaniciListesi
                .FirstOrDefault(k => k.KullaniciAdi.ToLower() == kullaniciAdi && k.Sifre == sifre);

            if (kullanici != null)
            {
                string hosgeldinMesaji = kullanici.Rol == "Admin"
                    ? $"Giriş başarılı! Hoş geldin {kullanici.KullaniciAdi} (Admin)"
                    : $"Giriş başarılı! Hoş geldin {kullanici.KullaniciAdi}";

                MessageBox.Show(hosgeldinMesaji, "Başarılı Giriş", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Ana formu aç, kullanıcı bilgisini gönder
                Form1 anaForm = new Form1(kullanici);
                anaForm.Show();

                // Giriş formunu gizle
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre hatalı!", "Giriş Başarısız", MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Şifre kutusunu temizleyip odakla
                txtSifre.Clear();
                txtSifre.Focus();
            }
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormGiris_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Uygulamadan çıkmak istediğinize emin misiniz?", "Çıkış", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                Application.Exit();
            }
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSifre_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
