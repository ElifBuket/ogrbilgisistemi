﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    public partial class FormIstatistik : Form
    {
        private List<Ogrenci> ogrenciListesi;

        public FormIstatistik(List<Ogrenci> liste)
        {
            InitializeComponent();

            // Liste null gelirse boş liste ata (güvenlik)
            ogrenciListesi = liste ?? new List<Ogrenci>();

            this.Load += FormIstatistik_Load;
        }

        private void FormIstatistik_Load(object sender, EventArgs e)
        {
            if (ogrenciListesi == null || ogrenciListesi.Count == 0)
            {
                MessageBox.Show("Öğrenci listesi boş!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                lblToplam.Text = "Toplam Öğrenci: 0";
                pbErkek.Value = 0;
                pbKadin.Value = 0;
                lstDogumYili.Items.Clear();

                return;
            }

            // 1. Toplam Öğrenci
            int toplamOgrenci = ogrenciListesi.Count;
            lblToplam.Text = $"Toplam Öğrenci: {toplamOgrenci}";

            // 2. Cinsiyet Dağılımı
            int erkekSayisi = ogrenciListesi.Count(o => o.Cinsiyet.Trim().ToLower() == "erkek");
            int kadinSayisi = ogrenciListesi.Count(o => o.Cinsiyet.Trim().ToLower() == "kadın");

            int toplamCinsiyet = erkekSayisi + kadinSayisi;

            int erkekYuzde = toplamCinsiyet > 0 ? (erkekSayisi * 100) / toplamCinsiyet : 0;
            int kadinYuzde = toplamCinsiyet > 0 ? (kadinSayisi * 100) / toplamCinsiyet : 0;

            // ProgressBar Ayarları
            pbErkek.Minimum = 0; pbErkek.Maximum = 100;
            pbKadin.Minimum = 0; pbKadin.Maximum = 100;

            pbErkek.Value = erkekYuzde;
            pbKadin.Value = kadinYuzde;

            lblErkek.Text = $"Erkek: %{erkekYuzde} ({erkekSayisi} kişi)";
            lblKadin.Text = $"Kadın: %{kadinYuzde} ({kadinSayisi} kişi)";

            // 3. Doğum Yılı Dağılımı
            var dogumYillari = ogrenciListesi
                .GroupBy(o => o.DogumTarihi.Year)
                .OrderBy(g => g.Key)
                .Select(g => $"{g.Key} Yılı: {g.Count()} Kişi")
                .ToList();

            lstDogumYili.Items.Clear();

            foreach (var item in dogumYillari)
                lstDogumYili.Items.Add(item);
        }

        private void pbErkek_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Erkek öğrenci oranı bilgisi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void pbKadin_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Kadın öğrenci oranı bilgisi.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void lstDogumYili_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDogumYili.SelectedItem != null)
            {
                MessageBox.Show(lstDogumYili.SelectedItem.ToString(), "Doğum Yılı Bilgisi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
