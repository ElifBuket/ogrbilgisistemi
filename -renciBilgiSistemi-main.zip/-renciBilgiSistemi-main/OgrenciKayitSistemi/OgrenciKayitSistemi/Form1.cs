﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    public partial class Form1 : Form
    {
        // Tüm formlar tarafından erişilebilen öğrenci listesi
        public static List<Ogrenci> ogrenciListesi = new List<Ogrenci>();

        // Giriş yapan kullanıcı
        private Kullanici aktifKullanici;

        // Constructor - Kullanıcı parametre olarak alınır
        public Form1(Kullanici kullanici)
        {
            InitializeComponent();
            aktifKullanici = kullanici;

            this.Load += Form1_Load; // Form yüklenince yapılacaklar
        
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (aktifKullanici == null)
            {
                MessageBox.Show("Kullanıcı bilgisi alınamadı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            lblKullaniciBilgi.Text = $"Hoş geldin, {aktifKullanici.KullaniciAdi} ({aktifKullanici.Rol})";

            if (aktifKullanici.Rol == "Kullanici")
            {
                öğrenciEkleToolStripMenuItem.Visible = false;
            }

            // Çıkış menüsü her zaman görünür
            cikisToolStripMenuItem.Visible = true;
        }

        private void öğrenciEkleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Yalnızca admin yetkisiyle açılabilir
            FormOgrenciEkle frm = new FormOgrenciEkle();
            frm.ShowDialog(); // Show yerine ShowDialog daha güvenli
        }

        private void öğrenciListeleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Tüm kullanıcılar görebilir
            FormOgrenciListele frm = new FormOgrenciListele();
            frm.ShowDialog();
        }

        private void istatistiklerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // İstatistik formunu aç ve öğrenci listesini gönder
            FormIstatistik frm = new FormIstatistik(Form1.ogrenciListesi);
            frm.ShowDialog();
        }

        private void cikisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Çıkış yapmak istiyor musunuz?", "Çıkış", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                FormGiris girisFormu = new FormGiris();
                girisFormu.Show();

                this.Close();
            }
        }
    }
}
