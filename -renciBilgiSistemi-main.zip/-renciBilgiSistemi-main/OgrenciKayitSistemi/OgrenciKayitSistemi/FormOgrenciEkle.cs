﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    public partial class FormOgrenciEkle : Form
    {
        public FormOgrenciEkle()
        {
            InitializeComponent();
            this.Load += FormOgrenciEkle_Load;
        }

        private void FormOgrenciEkle_Load(object sender, EventArgs e)
        {
            // Bölümleri yükle
            cmbBolum.Items.Clear();
            cmbBolum.Items.AddRange(new string[]
            {
                "Bilgisayar Mühendisliği",
                "Elektrik-Elektronik Mühendisliği",
                "Makine Mühendisliği"
            });

            // Dersleri yükle
            clbDersler.Items.Clear();
            clbDersler.Items.AddRange(new string[]
            {
                "Matematik",
                "Fizik",
                "Algoritma"
            });

            // Varsayılan cinsiyet
            rbErkek.Checked = true;
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            // Boş alan kontrolü
            if (string.IsNullOrWhiteSpace(txtAd.Text) ||
                string.IsNullOrWhiteSpace(txtSoyad.Text) ||
                string.IsNullOrWhiteSpace(txtTC.Text) ||
                cmbBolum.SelectedItem == null)
            {
                MessageBox.Show("Lütfen tüm zorunlu alanları doldurun!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (txtTC.Text.Length != 11)
            {
                MessageBox.Show("TC Kimlik Numarası 11 haneli olmalıdır!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // TC benzersiz mi?
            bool tcVarMi = Form1.ogrenciListesi.Any(o => o.TC == txtTC.Text);
            if (tcVarMi)
            {
                MessageBox.Show("Bu TC numarasına sahip öğrenci zaten kayıtlı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Doğum tarihi kontrolü
            DateTime dogumTarihi = dtpDogumTarihi.Value;
            if (dogumTarihi > DateTime.Now)
            {
                MessageBox.Show("Doğum tarihi gelecekte olamaz!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Bilgileri al
            string ad = txtAd.Text.Trim();
            string soyad = txtSoyad.Text.Trim();
            string tc = txtTC.Text.Trim();
            string cinsiyet = rbErkek.Checked ? "Erkek" : "Kadın";
            string bolum = cmbBolum.SelectedItem.ToString();

            // Seçilen dersler
            List<string> seciliDersler = clbDersler.CheckedItems.Cast<string>().ToList();
            string dersler = seciliDersler.Count > 0 ? string.Join(", ", seciliDersler) : "Ders seçilmedi";

            // Öğrenciyi oluştur
            Ogrenci yeniOgrenci = new Ogrenci()
            {
                Ad = ad,
                Soyad = soyad,

                TC = tc,
                DogumTarihi = dogumTarihi,
                Cinsiyet = cinsiyet,
                Bolum = bolum,
                Dersler = seciliDersler
            };

            // Listeye ekle
            Form1.ogrenciListesi.Add(yeniOgrenci);

            MessageBox.Show("Öğrenci başarıyla kaydedildi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Detaylı bilgi göster
            string mesaj = $"Ad: {ad}\nSoyad: {soyad}\nTC: {tc}\nDoğum Tarihi: {dogumTarihi.ToShortDateString()}\n" +
                           $"Cinsiyet: {cinsiyet}\nBölüm: {bolum}\nDersler: {dersler}";

            MessageBox.Show(mesaj, "Öğrenci Bilgileri", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Formu temizle
            Temizle();
        }

        private void Temizle()
        {
            txtAd.Clear();
            txtSoyad.Clear();
            txtTC.Clear();
            dtpDogumTarihi.Value = DateTime.Now;
            rbErkek.Checked = true;
            cmbBolum.SelectedIndex = -1;

            for (int i = 0; i < clbDersler.Items.Count; i++)
            {
                clbDersler.SetItemChecked(i, false);
            }
        }

        // Kullanılmayan eventler, ister kaldır ister yorum satırı yap
        private void label1_Click(object sender, EventArgs e) { }
        private void cmbBolum_SelectedIndexChanged(object sender, EventArgs e) { }
        private void clbDersler_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}
