﻿using System;
using System.Collections.Generic;

namespace OgrenciKayitSistemi
{
    [Serializable]
    public class Ogrenci
    {
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public string Cinsiyet { get; set; }
        public DateTime DogumTarihi { get; set; }
        public string TC { get; set; }
        public string Bolum { get; set; }

        public List<string> Dersler { get; set; }

        public Ogrenci()
        {
            Dersler = new List<string>();
        }

        public Ogrenci(string ad, string soyad, string cinsiyet, DateTime dogumTarihi, string tc, string bolum, List<string> dersler)
        {
            Ad = ad;
            Soyad = soyad;
            Cinsiyet = cinsiyet;
            DogumTarihi = dogumTarihi;
            TC = tc;
            Bolum = bolum;
            Dersler = dersler ?? new List<string>(); // Burada düzeltme yaptım!
        }

        public override string ToString()
        {
            return $"{Ad} {Soyad} - {Bolum}";
        }

        // ✨ Yeni özellik burada!
        public string DerslerGosterim
        {
            get
            {
                if (Dersler != null && Dersler.Count > 0)
                    return string.Join(", ", Dersler);
                else
                    return "-";
            }
        }
    }
}
