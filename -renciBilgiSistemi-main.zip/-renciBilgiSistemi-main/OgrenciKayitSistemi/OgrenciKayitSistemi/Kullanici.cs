﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OgrenciKayitSistemi
{
    public class Kullanici
    {
        public string KullaniciAdi { get; set; }
        public string Sifre { get; set; }
        public string Rol { get; set; }  // Admin veya Kullanici

        public Kullanici(string kullaniciAdi, string sifre, string rol)
        {
            KullaniciAdi = kullaniciAdi;
            Sifre = sifre;
            Rol = rol;
        }
    }
}

