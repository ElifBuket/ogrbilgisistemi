﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace OgrenciKayitSistemi
{
    public partial class FormOgrenciListele : Form
    {
        // İstatistik butonu
        private Button btnIstatistik;

        public FormOgrenciListele()
        {
            InitializeComponent();

            // Form yüklendiğinde işlemler
            this.Load += FormOgrenciListele_Load;

            // Olayları bağlama (tasarımda bağlanmadıysa!)
            txtAra.TextChanged += txtAra_TextChanged;
            btnSil.Click += btnSil_Click;
            btnGuncelle.Click += btnGuncelle_Click;

            // İstatistik butonunu oluştur
            btnIstatistik = new Button
            {
                Text = "İstatistikleri Gör",
                Width = 150,
                Height = 30,
                Top = btnGuncelle.Bottom + 10,
                Left = btnGuncelle.Left
            };

            // Event bağla
            btnIstatistik.Click += btnIstatistik_Click;

            // Forma ekle
            this.Controls.Add(btnIstatistik);

            // (Opsiyonel) DataGridView çift tıklamada güncelle açılması
            dgvOgrenciler.CellDoubleClick += dgvOgrenciler_CellDoubleClick;
        }

        private void FormOgrenciListele_Load(object sender, EventArgs e)
        {
            OgrenciListesiniGoster();
        }

        private void OgrenciListesiniGoster()
        {
            dgvOgrenciler.DataSource = null; // Önce temizle
            dgvOgrenciler.DataSource = Form1.ogrenciListesi; // Yeniden yükle

            // Kolon başlıklarını düzenleyebilirsin (isteğe bağlı)
            dgvOgrenciler.Columns["Ad"].HeaderText = "Ad";
            dgvOgrenciler.Columns["Soyad"].HeaderText = "Soyad";
            dgvOgrenciler.Columns["Cinsiyet"].HeaderText = "Cinsiyet";
            dgvOgrenciler.Columns["DogumTarihi"].HeaderText = "Doğum Tarihi";
        }

        private void txtAra_TextChanged(object sender, EventArgs e)
        {
            string aranan = txtAra.Text.Trim().ToLower();

            var filtreliListe = Form1.ogrenciListesi
                .Where(o => o.Ad.ToLower().Contains(aranan) || o.Soyad.ToLower().Contains(aranan))
                .ToList();

            dgvOgrenciler.DataSource = null;
            dgvOgrenciler.DataSource = filtreliListe;
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dgvOgrenciler.CurrentRow != null)
            {
                var seciliOgrenci = dgvOgrenciler.CurrentRow.DataBoundItem as Ogrenci;

                DialogResult sonuc = MessageBox.Show(
                    $"{seciliOgrenci.Ad} {seciliOgrenci.Soyad} öğrencisini silmek istiyor musunuz?",
                    "Öğrenci Sil",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (sonuc == DialogResult.Yes)
                {
                    Form1.ogrenciListesi.Remove(seciliOgrenci);
                    OgrenciListesiniGoster();
                    MessageBox.Show("Öğrenci başarıyla silindi.");
                }
            }
            else
            {
                MessageBox.Show("Lütfen silmek için bir öğrenci seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (dgvOgrenciler.CurrentRow != null)
            {
                var seciliOgrenci = dgvOgrenciler.CurrentRow.DataBoundItem as Ogrenci;

                string yeniAd = Microsoft.VisualBasic.Interaction.InputBox(
                    "Yeni adı giriniz:", "Ad Düzenle", seciliOgrenci.Ad);

                if (!string.IsNullOrWhiteSpace(yeniAd))
                {
                    seciliOgrenci.Ad = yeniAd;
                    OgrenciListesiniGoster();
                    MessageBox.Show("Öğrenci adı güncellendi.");
                }
            }
            else
            {
                MessageBox.Show("Güncellemek için bir öğrenci seçin!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnIstatistik_Click(object sender, EventArgs e)
        {
            if (Form1.ogrenciListesi == null || Form1.ogrenciListesi.Count == 0)
            {
                MessageBox.Show("Öğrenci listesi boş! İstatistik görüntülenemiyor.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            FormIstatistik frmIstatistik = new FormIstatistik(Form1.ogrenciListesi);
            frmIstatistik.ShowDialog(); // Modal
        }

        // Opsiyonel: Çift tıklamayla güncelleme aç
        private void dgvOgrenciler_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            btnGuncelle_Click(sender, e);
        }

        // Kullanılmayan eski textBox1 olayını silebilirsin
        // private void textBox1_TextChanged(object sender, EventArgs e) { }
    }
}
